# X Sentiment Reader

A lightweight website that scores market sentiment using **only X posts**. It deliberately does not use stock prices, charts, news, analyst ratings, fundamentals, or other market feeds.

## What it does
- Search an X query such as `$HGRAF`, `$AAPL`, `silver`, `gold`, or `copper`.
- Pull recent English posts through X API v2.
- Classify posts as bullish, bearish, or neutral with a finance-specific sentiment lexicon.
- Aggregate a sentiment score, bullish/bearish distribution, confidence, engagement, and freshness.
- Show the posts driving the signal.
- Runs in demo mode without an API key so the UI can be tested immediately.

## Run
Requires Node.js 18+.

1. Put the files in a folder.
2. Set `X_BEARER_TOKEN` in your environment.
3. Run `node server.js`.
4. Open `http://localhost:3000`.

Example on Windows PowerShell:

```powershell
$env:X_BEARER_TOKEN="YOUR_TOKEN"
node server.js
```

## Important X API note
The live version requires access to the relevant X API endpoints. X's developer documentation currently exposes the v2 recent-post search endpoint and indicates that enrollment in an applicable API access plan is required.

## Next version I would build
For a serious trading-grade version, replace the simple lexicon with a finance-tuned language model and add:
- sarcasm/context detection
- ticker/entity disambiguation
- author quality weighting
- bot/spam filtering
- bullish/bearish intensity rather than just polarity
- sentiment velocity and acceleration
- separate retail vs high-following-account sentiment
- sector/commodity dashboards
- historical X-sentiment charts
- alerts when sentiment crosses user-defined thresholds
- a backtesting page comparing X sentiment changes with subsequent price moves (while keeping price data completely separate from the sentiment calculation)
